window.FULLSCREEN_LOTTIE={
  "v": "5.5.9",
  "fr": 29.9700012207031,
  "ip": 0,
  "op": 59.0000024031193,
  "w": 25,
  "h": 25,
  "nm": "Comp 1",
  "ddd": 0,
  "assets": [],
  "layers": [
    {
      "ddd": 0,
      "ind": 14,
      "ty": 4,
      "nm": "Layer 4 Outlines",
      "sr": 1,
      "ks": {
        "o": {
          "a": 0,
          "k": 100,
          "ix": 11
        },
        "r": {
          "a": 0,
          "k": 0,
          "ix": 10
        },
        "p": {
          "a": 0,
          "k": [
            13.027,
            12.523,
            0
          ],
          "ix": 2,
          "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller 2')(1), 200);\n    freq = $bm_div(effect('Elastic Controller 2')(2), 30);\n    decay = $bm_div(effect('Elastic Controller 2')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
        },
        "a": {
          "a": 0,
          "k": [
            11.5,
            11.5,
            0
          ],
          "ix": 1
        },
        "s": {
          "a": 0,
          "k": [
            73.569,
            73.569,
            100
          ],
          "ix": 6
        }
      },
      "ao": 0,
      "ef": [
        {
          "ty": 5,
          "nm": "Elastic Controller",
          "np": 5,
          "mn": "Pseudo/MDS Elastic Controller",
          "ix": 1,
          "en": 1,
          "ef": [
            {
              "ty": 0,
              "nm": "Amplitude",
              "mn": "Pseudo/MDS Elastic Controller-0001",
              "ix": 1,
              "v": {
                "a": 0,
                "k": 20,
                "ix": 1
              }
            },
            {
              "ty": 0,
              "nm": "Frequency",
              "mn": "Pseudo/MDS Elastic Controller-0002",
              "ix": 2,
              "v": {
                "a": 0,
                "k": 40,
                "ix": 2
              }
            },
            {
              "ty": 0,
              "nm": "Decay",
              "mn": "Pseudo/MDS Elastic Controller-0003",
              "ix": 3,
              "v": {
                "a": 0,
                "k": 60,
                "ix": 3
              }
            }
          ]
        },
        {
          "ty": 5,
          "nm": "Elastic Controller 2",
          "np": 5,
          "mn": "Pseudo/MDS Elastic Controller",
          "ix": 2,
          "en": 1,
          "ef": [
            {
              "ty": 0,
              "nm": "Amplitude",
              "mn": "Pseudo/MDS Elastic Controller-0001",
              "ix": 1,
              "v": {
                "a": 0,
                "k": 20,
                "ix": 1
              }
            },
            {
              "ty": 0,
              "nm": "Frequency",
              "mn": "Pseudo/MDS Elastic Controller-0002",
              "ix": 2,
              "v": {
                "a": 0,
                "k": 40,
                "ix": 2
              }
            },
            {
              "ty": 0,
              "nm": "Decay",
              "mn": "Pseudo/MDS Elastic Controller-0003",
              "ix": 3,
              "v": {
                "a": 0,
                "k": 60,
                "ix": 3
              }
            }
          ]
        }
      ],
      "shapes": [
        {
          "ty": "gr",
          "it": [
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          2.49
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          -2.49,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "v": [
                        [
                          3.5,
                          3.5
                        ],
                        [
                          1,
                          3.5
                        ],
                        [
                          -3.5,
                          -1
                        ],
                        [
                          -3.5,
                          -3.5
                        ]
                      ],
                      "c": false
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 1.5,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      5,
                      18
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 1",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 1,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          2.49,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          2.49
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "v": [
                        [
                          2.991,
                          -4.005
                        ],
                        [
                          3,
                          -1.5
                        ],
                        [
                          -1.5,
                          3
                        ],
                        [
                          -3,
                          3
                        ]
                      ],
                      "c": false
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 1.5,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      18.5,
                      18.5
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 2",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 2,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          -2.49
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          2.49,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "v": [
                        [
                          -3.5,
                          -3.5
                        ],
                        [
                          -1,
                          -3.5
                        ],
                        [
                          3.5,
                          1
                        ],
                        [
                          3.5,
                          3.5
                        ]
                      ],
                      "c": false
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 1.5,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      18,
                      5
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 3",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 3,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          -2.49,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          -2.49
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "v": [
                        [
                          -3.5,
                          3.5
                        ],
                        [
                          -3.5,
                          1
                        ],
                        [
                          1,
                          -3.5
                        ],
                        [
                          3.5,
                          -3.5
                        ]
                      ],
                      "c": false
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 1.5,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      5,
                      5
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 4",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 4,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "tr",
              "p": {
                "a": 0,
                "k": [
                  11.5,
                  11.5
                ],
                "ix": 2,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller 2')(1), 200);\n    freq = $bm_div(effect('Elastic Controller 2')(2), 30);\n    decay = $bm_div(effect('Elastic Controller 2')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "a": {
                "a": 0,
                "k": [
                  11.5,
                  11.5
                ],
                "ix": 1
              },
              "s": {
                "a": 1,
                "k": [
                  {
                    "i": {
                      "x": [
                        0.59,
                        0.59
                      ],
                      "y": [
                        1,
                        1
                      ]
                    },
                    "o": {
                      "x": [
                        0.41,
                        0.41
                      ],
                      "y": [
                        0,
                        0
                      ]
                    },
                    "t": 16.784,
                    "s": [
                      100,
                      100
                    ]
                  },
                  {
                    "i": {
                      "x": [
                        0.833,
                        0.833
                      ],
                      "y": [
                        0.833,
                        0.833
                      ]
                    },
                    "o": {
                      "x": [
                        0.41,
                        0.41
                      ],
                      "y": [
                        0,
                        0
                      ]
                    },
                    "t": 25.175,
                    "s": [
                      82,
                      82
                    ]
                  },
                  {
                    "t": 34.7650014160075,
                    "s": [
                      100,
                      100
                    ]
                  }
                ],
                "ix": 3,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller 2')(1), 200);\n    freq = $bm_div(effect('Elastic Controller 2')(2), 30);\n    decay = $bm_div(effect('Elastic Controller 2')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "r": {
                "a": 1,
                "k": [
                  {
                    "i": {
                      "x": [
                        0.833
                      ],
                      "y": [
                        0.833
                      ]
                    },
                    "o": {
                      "x": [
                        0.41
                      ],
                      "y": [
                        0
                      ]
                    },
                    "t": 14.385,
                    "s": [
                      0
                    ]
                  },
                  {
                    "t": 32.3675013183553,
                    "s": [
                      90
                    ]
                  }
                ],
                "ix": 6,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller 2')(1), 200);\n    freq = $bm_div(effect('Elastic Controller 2')(2), 30);\n    decay = $bm_div(effect('Elastic Controller 2')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "o": {
                "a": 0,
                "k": 100,
                "ix": 7,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller 2')(1), 200);\n    freq = $bm_div(effect('Elastic Controller 2')(2), 30);\n    decay = $bm_div(effect('Elastic Controller 2')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "sk": {
                "a": 0,
                "k": 0,
                "ix": 4,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller 2')(1), 200);\n    freq = $bm_div(effect('Elastic Controller 2')(2), 30);\n    decay = $bm_div(effect('Elastic Controller 2')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "sa": {
                "a": 0,
                "k": 0,
                "ix": 5,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller 2')(1), 200);\n    freq = $bm_div(effect('Elastic Controller 2')(2), 30);\n    decay = $bm_div(effect('Elastic Controller 2')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "nm": "Transform"
            }
          ],
          "nm": "Group 1",
          "np": 4,
          "cix": 2,
          "bm": 0,
          "ix": 1,
          "mn": "ADBE Vector Group",
          "hd": false
        }
      ],
      "ip": 0,
      "op": 70.0000028511585,
      "st": 0,
      "bm": 0
    }
  ],
  "markers": []
};
window.COMMENT_LOTTIE={
  "v": "5.5.9",
  "fr": 29.9700012207031,
  "ip": 0,
  "op": 59.0000024031193,
  "w": 25,
  "h": 25,
  "nm": "Comp 1",
  "ddd": 0,
  "assets": [],
  "layers": [
    {
      "ddd": 0,
      "ind": 7,
      "ty": 4,
      "nm": "Layer 21 Outlines",
      "sr": 1,
      "ks": {
        "o": {
          "a": 0,
          "k": 100,
          "ix": 11
        },
        "r": {
          "a": 0,
          "k": 0,
          "ix": 10
        },
        "p": {
          "a": 0,
          "k": [
            12.402,
            13.211,
            0
          ],
          "ix": 2,
          "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller 2')(1), 200);\n    freq = $bm_div(effect('Elastic Controller 2')(2), 30);\n    decay = $bm_div(effect('Elastic Controller 2')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
        },
        "a": {
          "a": 0,
          "k": [
            13.74,
            13.855,
            0
          ],
          "ix": 1
        },
        "s": {
          "a": 0,
          "k": [
            73.569,
            73.569,
            100
          ],
          "ix": 6
        }
      },
      "ao": 0,
      "ef": [
        {
          "ty": 5,
          "nm": "Elastic Controller",
          "np": 5,
          "mn": "Pseudo/MDS Elastic Controller",
          "ix": 1,
          "en": 1,
          "ef": [
            {
              "ty": 0,
              "nm": "Amplitude",
              "mn": "Pseudo/MDS Elastic Controller-0001",
              "ix": 1,
              "v": {
                "a": 0,
                "k": 20,
                "ix": 1
              }
            },
            {
              "ty": 0,
              "nm": "Frequency",
              "mn": "Pseudo/MDS Elastic Controller-0002",
              "ix": 2,
              "v": {
                "a": 0,
                "k": 40,
                "ix": 2
              }
            },
            {
              "ty": 0,
              "nm": "Decay",
              "mn": "Pseudo/MDS Elastic Controller-0003",
              "ix": 3,
              "v": {
                "a": 0,
                "k": 60,
                "ix": 3
              }
            }
          ]
        }
      ],
      "shapes": [
        {
          "ty": "gr",
          "it": [
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "v": [
                        [
                          8.245,
                          15
                        ],
                        [
                          8.254,
                          15
                        ]
                      ],
                      "c": false
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 2,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 1",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 1,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "v": [
                        [
                          11.745,
                          15
                        ],
                        [
                          11.754,
                          15
                        ]
                      ],
                      "c": false
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 2,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 2",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 2,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "v": [
                        [
                          15.245,
                          15
                        ],
                        [
                          15.254,
                          15
                        ]
                      ],
                      "c": false
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 2,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 3",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 3,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 1,
                    "k": [
                      {
                        "i": {
                          "x": 0.49,
                          "y": 1
                        },
                        "o": {
                          "x": 0.51,
                          "y": 0
                        },
                        "t": 10.789,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                -3.19
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                2.69,
                                -0.23
                              ],
                              [
                                0,
                                0.26
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                3.19,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0.24,
                                -0.03
                              ],
                              [
                                -2.93,
                                0
                              ],
                              [
                                0,
                                0
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                2.94
                              ],
                              [
                                0.03,
                                -0.24
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                -3.19
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                -0.26,
                                0
                              ],
                              [
                                0.23,
                                -2.69
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                3.19,
                                0
                              ]
                            ],
                            "v": [
                              [
                                7.97,
                                -1.98
                              ],
                              [
                                7.97,
                                2.02
                              ],
                              [
                                3.93,
                                6.77
                              ],
                              [
                                3.97,
                                6.02
                              ],
                              [
                                3.97,
                                2.02
                              ],
                              [
                                -0.82,
                                -2.77
                              ],
                              [
                                -7.22,
                                -2.77
                              ],
                              [
                                -7.97,
                                -2.73
                              ],
                              [
                                -3.22,
                                -6.77
                              ],
                              [
                                3.18,
                                -6.77
                              ]
                            ],
                            "c": true
                          }
                        ]
                      },
                      {
                        "i": {
                          "x": 0.49,
                          "y": 1
                        },
                        "o": {
                          "x": 0.51,
                          "y": 0
                        },
                        "t": 22.778,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                -3.19
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0.349,
                                0.338
                              ],
                              [
                                0,
                                0.26
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                3.19,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0.24,
                                -0.03
                              ],
                              [
                                -1.03,
                                0.066
                              ],
                              [
                                0,
                                0
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                0.003,
                                1.083
                              ],
                              [
                                0.03,
                                -0.24
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                -3.19
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                -0.26,
                                0
                              ],
                              [
                                0.059,
                                -0.175
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                3.19,
                                0
                              ]
                            ],
                            "v": [
                              [
                                4.69,
                                1.3
                              ],
                              [
                                4.69,
                                5.3
                              ],
                              [
                                3.93,
                                6.77
                              ],
                              [
                                3.97,
                                6.02
                              ],
                              [
                                3.97,
                                2.02
                              ],
                              [
                                -0.82,
                                -2.77
                              ],
                              [
                                -7.22,
                                -2.77
                              ],
                              [
                                -7.97,
                                -2.73
                              ],
                              [
                                -6.5,
                                -3.49
                              ],
                              [
                                -0.1,
                                -3.49
                              ]
                            ],
                            "c": true
                          }
                        ]
                      },
                      {
                        "t": 32.3675013183553,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                -3.19
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                2.69,
                                -0.23
                              ],
                              [
                                0,
                                0.26
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                3.19,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0.24,
                                -0.03
                              ],
                              [
                                -2.93,
                                0
                              ],
                              [
                                0,
                                0
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                2.94
                              ],
                              [
                                0.03,
                                -0.24
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                -3.19
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                -0.26,
                                0
                              ],
                              [
                                0.23,
                                -2.69
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                3.19,
                                0
                              ]
                            ],
                            "v": [
                              [
                                7.97,
                                -1.98
                              ],
                              [
                                7.97,
                                2.02
                              ],
                              [
                                3.93,
                                6.77
                              ],
                              [
                                3.97,
                                6.02
                              ],
                              [
                                3.97,
                                2.02
                              ],
                              [
                                -0.82,
                                -2.77
                              ],
                              [
                                -7.22,
                                -2.77
                              ],
                              [
                                -7.97,
                                -2.73
                              ],
                              [
                                -3.22,
                                -6.77
                              ],
                              [
                                3.18,
                                -6.77
                              ]
                            ],
                            "c": true
                          }
                        ]
                      }
                    ],
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 1.5,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      15.76,
                      10.52
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 4",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 4,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          -3.19
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0.03,
                          -0.24
                        ],
                        [
                          2.93,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0.15,
                          -0.2
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0.53,
                          0.71
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0.22,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          4
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          -2.69,
                          0.23
                        ],
                        [
                          -0.26,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0.26
                        ],
                        [
                          -0.23,
                          2.7
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          -0.25,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          -0.53,
                          0.71
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          -0.13,
                          -0.17
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          -3.19,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          -2.93
                        ],
                        [
                          0.24,
                          -0.03
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          3.19,
                          0
                        ]
                      ],
                      "v": [
                        [
                          7.99,
                          -3.315
                        ],
                        [
                          7.99,
                          0.685
                        ],
                        [
                          7.95,
                          1.435
                        ],
                        [
                          3.2,
                          5.475
                        ],
                        [
                          2.8,
                          5.475
                        ],
                        [
                          2.16,
                          5.795
                        ],
                        [
                          0.96,
                          7.395
                        ],
                        [
                          -0.96,
                          7.395
                        ],
                        [
                          -2.16,
                          5.795
                        ],
                        [
                          -2.8,
                          5.475
                        ],
                        [
                          -3.2,
                          5.475
                        ],
                        [
                          -7.99,
                          0.685
                        ],
                        [
                          -7.99,
                          -3.315
                        ],
                        [
                          -3.95,
                          -8.065
                        ],
                        [
                          -3.2,
                          -8.105
                        ],
                        [
                          3.2,
                          -8.105
                        ]
                      ],
                      "c": true
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 1.5,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      11.74,
                      15.855
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 5",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 5,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "tr",
              "p": {
                "a": 1,
                "k": [
                  {
                    "i": {
                      "x": 0.49,
                      "y": 1
                    },
                    "o": {
                      "x": 0.51,
                      "y": 0
                    },
                    "t": 5.994,
                    "s": [
                      13.74,
                      13.766
                    ],
                    "to": [
                      0,
                      -0.794
                    ],
                    "ti": [
                      0,
                      0
                    ]
                  },
                  {
                    "i": {
                      "x": 0.833,
                      "y": 0.833
                    },
                    "o": {
                      "x": 0.51,
                      "y": 0
                    },
                    "t": 16.784,
                    "s": [
                      13.74,
                      9
                    ],
                    "to": [
                      0,
                      0
                    ],
                    "ti": [
                      0,
                      -0.794
                    ]
                  },
                  {
                    "t": 27.5725011230509,
                    "s": [
                      13.74,
                      13.766
                    ]
                  }
                ],
                "ix": 2,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller')(1), 200);\n    freq = $bm_div(effect('Elastic Controller')(2), 30);\n    decay = $bm_div(effect('Elastic Controller')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "a": {
                "a": 0,
                "k": [
                  13.74,
                  13.766
                ],
                "ix": 1,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller')(1), 200);\n    freq = $bm_div(effect('Elastic Controller')(2), 30);\n    decay = $bm_div(effect('Elastic Controller')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "s": {
                "a": 0,
                "k": [
                  100,
                  100
                ],
                "ix": 3,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller')(1), 200);\n    freq = $bm_div(effect('Elastic Controller')(2), 30);\n    decay = $bm_div(effect('Elastic Controller')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "r": {
                "a": 0,
                "k": 0,
                "ix": 6
              },
              "o": {
                "a": 0,
                "k": 100,
                "ix": 7
              },
              "sk": {
                "a": 0,
                "k": 0,
                "ix": 4
              },
              "sa": {
                "a": 0,
                "k": 0,
                "ix": 5
              },
              "nm": "Transform"
            }
          ],
          "nm": "Group 1",
          "np": 5,
          "cix": 2,
          "bm": 0,
          "ix": 1,
          "mn": "ADBE Vector Group",
          "hd": false
        }
      ],
      "ip": 0,
      "op": 73.000002973351,
      "st": 0,
      "bm": 0
    }
  ],
  "markers": []
};
window.DETAIL_LOTTIE={
  "v": "5.5.9",
  "fr": 29.9700012207031,
  "ip": 0,
  "op": 59.0000024031193,
  "w": 25,
  "h": 25,
  "nm": "Comp 1",
  "ddd": 0,
  "assets": [],
  "layers": [
    {
      "ddd": 0,
      "ind": 34,
      "ty": 4,
      "nm": "Layer 21 Outlines",
      "sr": 1,
      "ks": {
        "o": {
          "a": 0,
          "k": 100,
          "ix": 11
        },
        "r": {
          "a": 0,
          "k": 0,
          "ix": 10
        },
        "p": {
          "a": 0,
          "k": [
            12.688,
            14,
            0
          ],
          "ix": 2
        },
        "a": {
          "a": 0,
          "k": [
            11.5,
            11.5,
            0
          ],
          "ix": 1
        },
        "s": {
          "a": 0,
          "k": [
            89.375,
            89.375,
            100
          ],
          "ix": 6
        }
      },
      "ao": 0,
      "ef": [
        {
          "ty": 5,
          "nm": "Elastic Controller",
          "np": 5,
          "mn": "Pseudo/MDS Elastic Controller",
          "ix": 1,
          "en": 1,
          "ef": [
            {
              "ty": 0,
              "nm": "Amplitude",
              "mn": "Pseudo/MDS Elastic Controller-0001",
              "ix": 1,
              "v": {
                "a": 0,
                "k": 20,
                "ix": 1
              }
            },
            {
              "ty": 0,
              "nm": "Frequency",
              "mn": "Pseudo/MDS Elastic Controller-0002",
              "ix": 2,
              "v": {
                "a": 0,
                "k": 40,
                "ix": 2
              }
            },
            {
              "ty": 0,
              "nm": "Decay",
              "mn": "Pseudo/MDS Elastic Controller-0003",
              "ix": 3,
              "v": {
                "a": 0,
                "k": 60,
                "ix": 3
              }
            }
          ]
        }
      ],
      "shapes": [
        {
          "ty": "gr",
          "it": [
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "v": [
                        [
                          6.5,
                          16.5
                        ],
                        [
                          10.5,
                          16.5
                        ]
                      ],
                      "c": false
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 1.5,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 1",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 1,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "v": [
                        [
                          6.5,
                          12.5
                        ],
                        [
                          12.5,
                          12.5
                        ]
                      ],
                      "c": false
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 1.5,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 2",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 2,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "tr",
              "p": {
                "a": 1,
                "k": [
                  {
                    "i": {
                      "x": 0.45,
                      "y": 1
                    },
                    "o": {
                      "x": 0.55,
                      "y": 0
                    },
                    "t": 8.391,
                    "s": [
                      9.5,
                      14.5
                    ],
                    "to": [
                      0,
                      -1.092
                    ],
                    "ti": [
                      0,
                      0
                    ]
                  },
                  {
                    "i": {
                      "x": 0.833,
                      "y": 0.833
                    },
                    "o": {
                      "x": 0.55,
                      "y": 0
                    },
                    "t": 16.784,
                    "s": [
                      9.5,
                      7.948
                    ],
                    "to": [
                      0,
                      0
                    ],
                    "ti": [
                      0,
                      -1.092
                    ]
                  },
                  {
                    "t": 25.1750010253988,
                    "s": [
                      9.5,
                      14.5
                    ]
                  }
                ],
                "ix": 2,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller')(1), 200);\n    freq = $bm_div(effect('Elastic Controller')(2), 30);\n    decay = $bm_div(effect('Elastic Controller')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "a": {
                "a": 0,
                "k": [
                  9.5,
                  14.5
                ],
                "ix": 1
              },
              "s": {
                "a": 0,
                "k": [
                  100,
                  100
                ],
                "ix": 3
              },
              "r": {
                "a": 0,
                "k": 0,
                "ix": 6
              },
              "o": {
                "a": 0,
                "k": 100,
                "ix": 7
              },
              "sk": {
                "a": 0,
                "k": 0,
                "ix": 4
              },
              "sa": {
                "a": 0,
                "k": 0,
                "ix": 5
              },
              "nm": "Transform"
            }
          ],
          "nm": "Group 5",
          "np": 2,
          "cix": 2,
          "bm": 0,
          "ix": 1,
          "mn": "ADBE Vector Group",
          "hd": false
        },
        {
          "ty": "gr",
          "it": [
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 1,
                    "k": [
                      {
                        "i": {
                          "x": 0.833,
                          "y": 0.833
                        },
                        "o": {
                          "x": 0.167,
                          "y": 0.167
                        },
                        "t": 8.391,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                3
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                -3,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ]
                            ],
                            "v": [
                              [
                                4,
                                4
                              ],
                              [
                                0,
                                4
                              ],
                              [
                                -4,
                                0
                              ],
                              [
                                -4,
                                -4
                              ],
                              [
                                -0.065,
                                -0.065
                              ]
                            ],
                            "c": true
                          }
                        ]
                      },
                      {
                        "i": {
                          "x": 0.833,
                          "y": 0.833
                        },
                        "o": {
                          "x": 0.167,
                          "y": 0.167
                        },
                        "t": 11.988,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                1.025,
                                2.978
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                -0.394,
                                -0.447
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                -3.279,
                                -0.612
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0.328,
                                0.372
                              ]
                            ],
                            "v": [
                              [
                                4,
                                4
                              ],
                              [
                                1.977,
                                3.983
                              ],
                              [
                                -4.008,
                                -1.978
                              ],
                              [
                                -4,
                                -4
                              ],
                              [
                                -0.032,
                                -0.141
                              ]
                            ],
                            "c": true
                          }
                        ]
                      },
                      {
                        "i": {
                          "x": 0.833,
                          "y": 0.833
                        },
                        "o": {
                          "x": 0.167,
                          "y": 0.167
                        },
                        "t": 13.186,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0.764,
                                1.966
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                -0.635,
                                -0.629
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                -5.517,
                                -2.174
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                1.301,
                                1.289
                              ]
                            ],
                            "v": [
                              [
                                4,
                                4
                              ],
                              [
                                3.785,
                                4.061
                              ],
                              [
                                -4.006,
                                -3.916
                              ],
                              [
                                -4,
                                -4
                              ],
                              [
                                0.199,
                                -0.179
                              ]
                            ],
                            "c": true
                          }
                        ]
                      },
                      {
                        "i": {
                          "x": 0.32,
                          "y": 1
                        },
                        "o": {
                          "x": 0.167,
                          "y": 0.167
                        },
                        "t": 14.385,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                2.412,
                                0.258
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                -0.788,
                                -0.894
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                -1.55,
                                -4.209
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0.657,
                                0.745
                              ]
                            ],
                            "v": [
                              [
                                4,
                                4
                              ],
                              [
                                3.954,
                                3.966
                              ],
                              [
                                -4.015,
                                -3.957
                              ],
                              [
                                -4,
                                -4
                              ],
                              [
                                1.207,
                                -1.165
                              ]
                            ],
                            "c": true
                          }
                        ]
                      },
                      {
                        "i": {
                          "x": 0.833,
                          "y": 0.833
                        },
                        "o": {
                          "x": 0.68,
                          "y": 0
                        },
                        "t": 17.983,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                4.199,
                                0.279
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                -1.697,
                                -1.925
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                0.121,
                                -9.06
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                1.414,
                                1.603
                              ]
                            ],
                            "v": [
                              [
                                4,
                                4
                              ],
                              [
                                3.966,
                                4.112
                              ],
                              [
                                -4.035,
                                -4.064
                              ],
                              [
                                -4,
                                -4
                              ],
                              [
                                2.672,
                                -2.433
                              ]
                            ],
                            "c": true
                          }
                        ]
                      },
                      {
                        "i": {
                          "x": 0.833,
                          "y": 0.833
                        },
                        "o": {
                          "x": 0.167,
                          "y": 0.167
                        },
                        "t": 22.778,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                3.054,
                                1.021
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                -1.234,
                                -1.4
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                -0.73,
                                -6.59
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                1.028,
                                1.166
                              ]
                            ],
                            "v": [
                              [
                                4,
                                4
                              ],
                              [
                                3.962,
                                3.952
                              ],
                              [
                                -3.939,
                                -4.033
                              ],
                              [
                                -4,
                                -4
                              ],
                              [
                                1.926,
                                -1.787
                              ]
                            ],
                            "c": true
                          }
                        ]
                      },
                      {
                        "i": {
                          "x": 0.833,
                          "y": 0.833
                        },
                        "o": {
                          "x": 0.167,
                          "y": 0.167
                        },
                        "t": 25.175,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0.373,
                                3.249
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                -0.831,
                                -0.926
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                -3.943,
                                -0.693
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                1.412,
                                1.558
                              ]
                            ],
                            "v": [
                              [
                                4,
                                4
                              ],
                              [
                                3.762,
                                3.968
                              ],
                              [
                                -3.873,
                                -3.81
                              ],
                              [
                                -4,
                                -4
                              ],
                              [
                                0.056,
                                -0.265
                              ]
                            ],
                            "c": true
                          }
                        ]
                      },
                      {
                        "i": {
                          "x": 0.833,
                          "y": 0.833
                        },
                        "o": {
                          "x": 0.167,
                          "y": 0.167
                        },
                        "t": 26.374,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0.168,
                                2.715
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                -0.63,
                                -0.689
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                -4.231,
                                -0.562
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                1.604,
                                1.753
                              ]
                            ],
                            "v": [
                              [
                                4,
                                4
                              ],
                              [
                                1.981,
                                3.976
                              ],
                              [
                                -3.97,
                                -2.017
                              ],
                              [
                                -4,
                                -4
                              ],
                              [
                                0.026,
                                -0.538
                              ]
                            ],
                            "c": true
                          }
                        ]
                      },
                      {
                        "t": 31.1687512695292,
                        "s": [
                          {
                            "i": [
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                3
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ]
                            ],
                            "o": [
                              [
                                0,
                                0
                              ],
                              [
                                -3,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ],
                              [
                                0,
                                0
                              ]
                            ],
                            "v": [
                              [
                                4,
                                4
                              ],
                              [
                                0,
                                4
                              ],
                              [
                                -4,
                                0
                              ],
                              [
                                -4,
                                -4
                              ],
                              [
                                -0.065,
                                -0.065
                              ]
                            ],
                            "c": true
                          }
                        ]
                      }
                    ],
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 1.5,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      17.5,
                      5.5
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 1",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 1,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "gr",
              "it": [
                {
                  "ind": 0,
                  "ty": "sh",
                  "ix": 1,
                  "ks": {
                    "a": 0,
                    "k": {
                      "i": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          5,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          5
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          -5,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "o": [
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          5
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          -5,
                          0
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          -5
                        ],
                        [
                          0,
                          0
                        ],
                        [
                          0,
                          0
                        ]
                      ],
                      "v": [
                        [
                          10,
                          -2
                        ],
                        [
                          10,
                          3
                        ],
                        [
                          3,
                          10
                        ],
                        [
                          -3,
                          10
                        ],
                        [
                          -10,
                          3
                        ],
                        [
                          -10,
                          -3
                        ],
                        [
                          -3,
                          -10
                        ],
                        [
                          2,
                          -10
                        ]
                      ],
                      "c": false
                    },
                    "ix": 2
                  },
                  "nm": "Path 1",
                  "mn": "ADBE Vector Shape - Group",
                  "hd": false
                },
                {
                  "ty": "st",
                  "c": {
                    "a": 0,
                    "k": [
                      1,
                      1,
                      1,
                      1
                    ],
                    "ix": 3
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 4
                  },
                  "w": {
                    "a": 0,
                    "k": 1.5,
                    "ix": 5
                  },
                  "lc": 2,
                  "lj": 2,
                  "bm": 0,
                  "nm": "Stroke 1",
                  "mn": "ADBE Vector Graphic - Stroke",
                  "hd": false
                },
                {
                  "ty": "tr",
                  "p": {
                    "a": 0,
                    "k": [
                      11.5,
                      11.5
                    ],
                    "ix": 2
                  },
                  "a": {
                    "a": 0,
                    "k": [
                      0,
                      0
                    ],
                    "ix": 1
                  },
                  "s": {
                    "a": 0,
                    "k": [
                      100,
                      100
                    ],
                    "ix": 3
                  },
                  "r": {
                    "a": 0,
                    "k": 0,
                    "ix": 6
                  },
                  "o": {
                    "a": 0,
                    "k": 100,
                    "ix": 7
                  },
                  "sk": {
                    "a": 0,
                    "k": 0,
                    "ix": 4
                  },
                  "sa": {
                    "a": 0,
                    "k": 0,
                    "ix": 5
                  },
                  "nm": "Transform"
                }
              ],
              "nm": "Group 2",
              "np": 2,
              "cix": 2,
              "bm": 0,
              "ix": 2,
              "mn": "ADBE Vector Group",
              "hd": false
            },
            {
              "ty": "tr",
              "p": {
                "a": 1,
                "k": [
                  {
                    "i": {
                      "x": 0.45,
                      "y": 1
                    },
                    "o": {
                      "x": 0.55,
                      "y": 0
                    },
                    "t": 4.795,
                    "s": [
                      11.5,
                      11.5
                    ],
                    "to": [
                      0,
                      -0.69
                    ],
                    "ti": [
                      0,
                      0
                    ]
                  },
                  {
                    "i": {
                      "x": 0.833,
                      "y": 0.833
                    },
                    "o": {
                      "x": 0.55,
                      "y": 0
                    },
                    "t": 14.385,
                    "s": [
                      11.5,
                      7.362
                    ],
                    "to": [
                      0,
                      0
                    ],
                    "ti": [
                      0,
                      -0.69
                    ]
                  },
                  {
                    "t": 22.7775009277466,
                    "s": [
                      11.5,
                      11.5
                    ]
                  }
                ],
                "ix": 2,
                "x": "var $bm_rt;\nvar amp, freq, decay, n, n, t, t, v;\ntry {\n    amp = $bm_div(effect('Elastic Controller')(1), 200);\n    freq = $bm_div(effect('Elastic Controller')(2), 30);\n    decay = $bm_div(effect('Elastic Controller')(3), 10);\n    $bm_rt = n = 0;\n    if (numKeys > 0) {\n        $bm_rt = n = nearestKey(time).index;\n        if (key(n).time > time) {\n            n--;\n        }\n    }\n    if (n == 0) {\n        $bm_rt = t = 0;\n    } else {\n        $bm_rt = t = $bm_sub(time, key(n).time);\n    }\n    if (n > 0) {\n        v = velocityAtTime($bm_sub(key(n).time, $bm_div(thisComp.frameDuration, 10)));\n        $bm_rt = $bm_sum(value, $bm_div($bm_mul($bm_mul(v, amp), Math.sin($bm_mul($bm_mul($bm_mul(freq, t), 2), Math.PI))), Math.exp($bm_mul(decay, t))));\n    } else {\n        $bm_rt = value;\n    }\n} catch (e$$4) {\n    $bm_rt = value = value;\n}"
              },
              "a": {
                "a": 0,
                "k": [
                  11.5,
                  11.5
                ],
                "ix": 1
              },
              "s": {
                "a": 0,
                "k": [
                  100,
                  100
                ],
                "ix": 3
              },
              "r": {
                "a": 0,
                "k": 0,
                "ix": 6
              },
              "o": {
                "a": 0,
                "k": 100,
                "ix": 7
              },
              "sk": {
                "a": 0,
                "k": 0,
                "ix": 4
              },
              "sa": {
                "a": 0,
                "k": 0,
                "ix": 5
              },
              "nm": "Transform"
            }
          ],
          "nm": "Group 4",
          "np": 2,
          "cix": 2,
          "bm": 0,
          "ix": 2,
          "mn": "ADBE Vector Group",
          "hd": false
        }
      ],
      "ip": 0,
      "op": 63.0000025660426,
      "st": 0,
      "bm": 0
    }
  ],
  "markers": []
};
